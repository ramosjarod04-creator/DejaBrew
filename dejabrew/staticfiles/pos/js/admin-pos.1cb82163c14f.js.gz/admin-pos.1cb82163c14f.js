// Admin POS JavaScript - With Ingredient Stock Validation & Deduction

let cart = [];
let allProducts = [];
let productsByCategory = {};
let allIngredients = [];

let mobileCartToggleBtn;
let mobileCartCloseBtn;
let cartCol;

// Debouncing variables for notifications
let lastNotificationTime = {};
const NOTIFICATION_DEBOUNCE_MS = 5000; // Only show same notification once every 5 seconds

// --- PAYMENT MODAL VARIABLES ---
let paymentModal;
let paymentModalTitle;
let paymentCustomerName;
let paymentRefNum;
let paymentModalCancel;
let paymentModalConfirm;
let paymentModalResolve = null;

// --- ADD-ONS MODAL VARIABLES ---
let addOnsModal;
let addOnsProductName;
let addOnsGrid;
let addOnsSkipBtn;
let addOnsContinueBtn;
let selectedAddOns = [];
let addOnsModalResolve = null;

// --- DISCOUNT MODAL VARIABLES ---
let discountModal;
let discountTypeSelect;
let discountIdInput;
let discountIdGroup;
let discountModalCancel;
let discountModalApply;
let discountModalResolve = null;

// --- RECEIPT PREVIEW MODAL VARIABLES ---
let receiptPreviewModal;
let receiptPreviewClose;
let receiptPreviewPrint;
let receiptPreviewContent;
// Store the current receipt HTML for printing
let currentReceiptHTML = ""; 


// --- UTILITY FUNCTIONS ---

function getCSRFToken() {
    return document.querySelector('[name=csrfmiddlewaretoken]')?.value || 
           document.cookie.split('; ')
               .find(row => row.startsWith('csrftoken='))
               ?.split('=')[1] || '';
}

function getParentCategory(specificCategory) {
    const categoryMap = {
        'Hot Coffee': 'Drinks', 'Iced Coffee': 'Drinks', 'Frappuccino': 'Drinks',
        'Fruit Tea Series': 'Drinks', 'Cheese Macchiato Series': 'Drinks',
        'Matcha Series': 'Drinks', 'Non - Coffee Over Iced': 'Drinks',
        'Float Series': 'Drinks', 'Holiday Specials': 'Drinks',
        'Croffles': 'Food'
    };
    return categoryMap[specificCategory] || specificCategory;
}

function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function escapeJs(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[\\"']/g, '\\$&').replace(/\u0000/g, '\\0');
}

// Placeholder image data URL (gray square with "No Image" text)
const PLACEHOLDER_IMAGE = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2UwZTBlMCIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9IiM5OTk5OTkiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5ObyBJbWFnZTwvdGV4dD48L3N2Zz4=';

function showNotification(message, type = 'info', debounce = false) {
    // Debounce check - prevent duplicate notifications
    if (debounce) {
        const now = Date.now();
        const key = `${message}-${type}`;
        if (lastNotificationTime[key] && (now - lastNotificationTime[key]) < NOTIFICATION_DEBOUNCE_MS) {
            console.log(`Debounced notification: ${message}`);
            return; // Skip this notification
        }
        lastNotificationTime[key] = now;
    }

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    Object.assign(notification.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        padding: '20px 32px',
        borderRadius: '12px',
        zIndex: '10000',
        fontWeight: '600',
        boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
        animation: 'fadeInScale 0.3s ease',
        minWidth: '300px',
        maxWidth: '500px',
        fontSize: '16px',
        background: '#fff',
        textAlign: 'center'
    });
    const colors = {
        success: { bg: '#d4edda', color: '#155724', border: '#c3e6cb' },
        error: { bg: '#f8d7da', color: '#721c24', border: '#f5c6cb' },
        info: { bg: '#d1ecf1', color: '#0c5460', border: '#bee5eb' }
    };
    const color = colors[type] || colors.info;
    notification.style.background = color.bg;
    notification.style.color = color.color;
    notification.style.border = `2px solid ${color.border}`;

    const styleId = 'notification-keyframes-admin';
    if (!document.getElementById(styleId)) {
        const styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = `
            @keyframes fadeInScale {
                from { transform: translate(-50%, -50%) scale(0.8); opacity: 0; }
                to { transform: translate(-50%, -50%) scale(1); opacity: 1; }
            }
            @keyframes fadeOutScale {
                from { transform: translate(-50%, -50%) scale(1); opacity: 1; }
                to { transform: translate(-50%, -50%) scale(0.8); opacity: 0; }
            }
        `;
        document.head.appendChild(styleElement);
    }

    document.body.appendChild(notification);
    setTimeout(() => {
        notification.style.animation = 'fadeOutScale 0.3s ease forwards';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}


// --- INITIALIZATION & EVENT LISTENERS ---

document.addEventListener('DOMContentLoaded', async function() {
    await loadIngredients();
    await loadProducts();
    await loadAndRenderCategories(); // NEW: Load and render dynamic category buttons

    // loadRecentOrders(); // REMOVED: Recent Orders panel no longer needed
    setupEventListeners();
    updateCartDisplay();
    createAddOnsModal();
    setupDiscountModal();
    setupReceiptPreviewModal();
    setupOrderCompleteModal(); // Initialize Order Complete Modal
    setupButtonControls(); // NEW: Setup button-based controls
    setupAdminPasswordModal(); // NEW: Setup admin authentication
});

function setupEventListeners() {
    const searchInput = document.getElementById('searchInput');
    const processOrderBtn = document.getElementById('processOrderBtn');
    const clearCartBtn = document.getElementById('clearCartBtn');
    const discountInput = document.getElementById('discountInput');
    const applyDiscountBtn = document.getElementById('applyDiscountBtn');

    if (searchInput) searchInput.addEventListener('input', handleSearch);
    if (processOrderBtn) processOrderBtn.addEventListener('click', processOrder);
    if (clearCartBtn) clearCartBtn.addEventListener('click', clearCart);
    if (discountInput) discountInput.addEventListener('input', updateCartTotals);
    // Admin auth required for discount
    if (applyDiscountBtn) applyDiscountBtn.addEventListener('click', requireAdminForDiscount);

    // Storage event listener - ONLY fires when OTHER tabs/windows update localStorage
    // This allows cross-tab synchronization without creating infinite loops
    window.addEventListener('storage', (event) => {
        if (event.key === 'productUpdate') {
            console.log('Storage event: productUpdate detected from another tab');
            showNotification('Product list has been updated.', 'info', true); // Debounced
            loadProducts();
        }
        // When another tab updates ingredients, sync without triggering another save
        if (event.key === 'dejabrew_ingredients_v1') {
            console.log('Storage event: ingredients updated from another tab');
            // Load directly from localStorage to avoid API call and prevent save loop
            try {
                const stored = localStorage.getItem('dejabrew_ingredients_v1');
                if (stored) {
                    const parsedIngredients = JSON.parse(stored);
                    // Only update if data actually changed
                    if (JSON.stringify(parsedIngredients) !== JSON.stringify(allIngredients)) {
                        allIngredients = parsedIngredients;
                        console.log(`📦 Synced ${allIngredients.length} ingredients from another tab`);
                        showNotification('Inventory has been updated.', 'info', true); // Debounced
                        const currentCategory = document.getElementById('productsGrid')?.dataset.currentCategory || 'all';
                        showProductView(currentCategory);
                    }
                }
            } catch (error) {
                console.error('Error syncing ingredients from storage:', error);
            }
        }
    });

    mobileCartToggleBtn = document.getElementById('mobileCartToggle');
    mobileCartCloseBtn = document.getElementById('mobileCartClose');
    cartCol = document.querySelector('.cart-col');

    if (mobileCartToggleBtn) {
        mobileCartToggleBtn.addEventListener('click', toggleMobileCart);
    }
    if (mobileCartCloseBtn) {
        mobileCartCloseBtn.addEventListener('click', toggleMobileCart);
    }

    paymentModal = document.getElementById('paymentModal');
    paymentModalTitle = document.getElementById('paymentModalTitle');
    paymentCustomerName = document.getElementById('paymentCustomerName');
    paymentRefNum = document.getElementById('paymentRefNum');
    paymentModalCancel = document.getElementById('paymentModalCancel');
    paymentModalConfirm = document.getElementById('paymentModalConfirm');

    if (paymentModal && paymentModalCancel && paymentModalConfirm) {
        paymentModalCancel.addEventListener('click', closePaymentModal);
        paymentModalConfirm.addEventListener('click', confirmPaymentDetails);
        paymentModal.addEventListener('click', (e) => {
            if (e.target === paymentModal) closePaymentModal();
        });
    }
}


// --- DATA LOADING & SAVING ---

async function loadIngredients(skipSave = false) {
    try {
        const response = await fetch('/api/ingredients/');
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();

        const newIngredients = data.results || data;

        if (!Array.isArray(newIngredients)) {
             console.error("Fetched ingredients data is not an array:", data);
             allIngredients = [];
             return;
        }

        console.log(`📦 Loaded ${newIngredients.length} ingredients from server.`);

        // Only save if data changed and skipSave is false (prevents unnecessary storage events)
        if (!skipSave) {
            const dataChanged = JSON.stringify(newIngredients) !== JSON.stringify(allIngredients);
            if (dataChanged) {
                allIngredients = newIngredients;
                saveIngredients();
                console.log('✓ Ingredients data changed, saved to localStorage');
            } else {
                allIngredients = newIngredients;
                console.log('✓ Ingredients data unchanged, skipping save');
            }
        } else {
            allIngredients = newIngredients;
        }
    } catch (error) {
        console.error("Error loading ingredients:", error);
        showNotification("Could not load ingredients. Trying local cache.", "error");
        const stored = localStorage.getItem('dejabrew_ingredients_v1');
        if (stored) {
            allIngredients = JSON.parse(stored);
            console.log(`📦 Loaded ${allIngredients.length} ingredients from local cache as fallback.`);
        } else {
            allIngredients = [];
        }
    }
}

function saveIngredients() {
    localStorage.setItem('dejabrew_ingredients_v1', JSON.stringify(allIngredients));
    localStorage.setItem('inventoryUpdate', Date.now().toString());
}

async function loadProducts() {
    try {
        const response = await fetch(`/api/products/?t=${new Date().getTime()}`);
        const data = await response.json();
        if (data.success) {
            allProducts = data.products;
            groupProductsByCategory();
            showCategoryView();
        } else {
            showNotification('Failed to load products', 'error');
        }
    } catch (error) {
        console.error('Error loading products:', error);
        showNotification('Failed to load products', 'error');
    }
}

async function loadAndRenderCategories() {
    try {
        const response = await fetch('/api/product-categories/');
        const data = await response.json();

        if (data.success && data.categories) {
            renderCategoryButtons(data.categories);
        } else {
            console.error('Failed to load categories');
            // Fallback to basic categories
            renderCategoryButtons(['Food', 'Drinks', 'Frappuccino']);
        }
    } catch (error) {
        console.error('Error loading categories:', error);
        // Fallback to basic categories
        renderCategoryButtons(['Food', 'Drinks', 'Frappuccino']);
    }
}

function renderCategoryButtons(categories) {
    const container = document.getElementById('categoryButtonsContainer');
    if (!container) return;

    // Clear existing buttons
    container.innerHTML = '';

    // Add "All Products" button first
    const allBtn = createCategoryButton('All Products', 'all', true);
    container.appendChild(allBtn);

    // Add category buttons from database
    categories.forEach(category => {
        const btn = createCategoryButton(category, category.toLowerCase(), false);
        container.appendChild(btn);
    });

    // Add "Best Selling" button last with special styling
    const bestSellingBtn = createCategoryButton('🔥 Best Selling', 'bestselling', false, true);
    container.appendChild(bestSellingBtn);

    // Re-setup button controls after rendering
    setupButtonControls();
}

function createCategoryButton(label, categoryValue, isActive, isBestSelling = false) {
    const btn = document.createElement('button');
    btn.className = 'category-btn' + (isActive ? ' active' : '');
    btn.dataset.category = categoryValue;

    // Base styling
    btn.style.cssText = `
        flex: 1;
        min-width: 120px;
        padding: 12px;
        border: 2px solid ${isActive ? '#8B4513' : (isBestSelling ? '#ffc107' : '#ddd')};
        background: ${isActive ? '#8B4513' : (isBestSelling ? '#ffc107' : 'white')};
        color: ${isActive ? 'white' : (isBestSelling ? '#333' : '#333')};
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
    `;

    btn.textContent = label;

    return btn;
}

async function loadRecentOrders() {
    try {
        const response = await fetch('/api/recent-orders/');
        const data = await response.json();
        const recentOrdersContainer = document.getElementById('recentOrders');
        if (data.orders && data.orders.length > 0) {
            recentOrdersContainer.innerHTML = data.orders.map(order => `
                <div class="recent-order-item">
                    <span>Order #${order.id} (${order.created_at}) - <em>${order.dining_option || 'Dine-In'}</em></span>
                    <strong>₱${parseFloat(order.total).toFixed(2)}</strong>
                </div>
            `).join('');
        } else {
            recentOrdersContainer.innerHTML = '<p class="muted">No recent orders to display.</p>';
        }
    } catch (error) {
        console.error('Error loading recent orders:', error);
    }
}


// --- RENDERING & UI ---

function groupProductsByCategory() {
    productsByCategory = { 'all': allProducts };
    allProducts.forEach(product => {
        const parentCategory = getParentCategory(product.category || 'General');
        if (!productsByCategory[parentCategory]) {
            productsByCategory[parentCategory] = [];
        }
        productsByCategory[parentCategory].push(product);
    });
}

function populateCategorySelect() {
    const categorySelect = document.getElementById('categorySelect');
    if (!categorySelect) return;
    
    const parentCategories = [...new Set(allProducts.map(p => getParentCategory(p.category || 'General')))].sort();

    categorySelect.innerHTML = '<option value="all">All Products</option>';
    parentCategories.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categorySelect.appendChild(option);
    });
}

function renderProducts(products) {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;
    if (!products || products.length === 0) {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #666;">No products found.</p>';
        return;
    }

    grid.innerHTML = products.map(product => {
        const hasStock = (product.stock || 0) > 0;
        const hasRecipe = product.recipe && product.recipe.length > 0;
        let isDisabled = false;
        let outOfStockReason = '';
        let stockStatusText = '';

        if (hasStock) {
            stockStatusText = `Stock: ${product.stock}`;
            isDisabled = false;
        } else if (hasRecipe) {
            const { maxCanMake, missingIngredient } = calculateMaxRecipeStock(product);
            if (maxCanMake > 0) {
                stockStatusText = `Can make: ${maxCanMake}`;
                isDisabled = false;
            } else {
                stockStatusText = 'Recipe Item';
                isDisabled = true;
                outOfStockReason = missingIngredient ? `No ${missingIngredient}` : 'Out of Stock';
            }
        } else {
            stockStatusText = `Stock: ${product.stock}`;
            isDisabled = true;
            outOfStockReason = 'Out of Stock';
        }
        
        return `
        <div class="product-card ${isDisabled ? 'disabled' : ''}">
            <div class="product-image" style="background-image: url('${product.image_url || PLACEHOLDER_IMAGE}')"></div>
            <div class="product-info">
                <div class="title" title="${escapeHtml(product.name)}">${escapeHtml(product.name)}</div>
                <div class="desc">${stockStatusText}</div>
            </div>
            <div class="product-footer">
                <div class="price">₱${parseFloat(product.price).toFixed(2)}</div>
                ${isDisabled
                    ? `<span class="stock-badge" style="background-color: #e55353;">${outOfStockReason}</span>`
                    : `<button class="add-btn" onclick="addToCart(${product.id})" style="padding: 14px 20px; font-size: 16px; font-weight: 700; min-height: 48px;">Add</button>`
                }
            </div>
        </div>
    `;
    }).join('');
}


// --- INVENTORY & RECIPE LOGIC ---

function calculateMaxRecipeStock(product) {
    if (!product.recipe || product.recipe.length === 0) {
        return { maxCanMake: 0, missingIngredient: null };
    }
    
    let maxCanMake = Infinity;
    let bottleneck = null;

    for (const recipeItem of product.recipe) {
        const ingredient = allIngredients.find(ing => ing.name === recipeItem.ingredient);
        if (!ingredient) {
            console.warn(`Ingredient "${recipeItem.ingredient}" for product "${product.name}" not found in inventory.`);
            return { maxCanMake: 0, missingIngredient: recipeItem.ingredient };
        }
        
        const neededPerItem = parseFloat(recipeItem.quantity);
        if (neededPerItem <= 0) continue;

        const availableStock = parseFloat(ingredient.mainStock || 0);
        
        if (availableStock <= 0) {
            return { maxCanMake: 0, missingIngredient: recipeItem.ingredient };
        }

        const canMakeFromThis = availableStock / neededPerItem;
        
        if (canMakeFromThis < maxCanMake) {
            maxCanMake = canMakeFromThis;
            bottleneck = recipeItem.ingredient;
        }
    }

    if (maxCanMake === Infinity) {
        return { maxCanMake: 0, missingIngredient: null };
    }
    
    const finalAmount = Math.floor(maxCanMake);
    return { 
        maxCanMake: finalAmount, 
        missingIngredient: finalAmount > 0 ? null : bottleneck 
    };
}

function checkIfCanMakeProduct(product, quantity = 1) {
    const { maxCanMake, missingIngredient } = calculateMaxRecipeStock(product);
    if (quantity > maxCanMake) {
        return { canMake: false, missingIngredient: missingIngredient || 'Stock' };
    }
    return { canMake: true, missingIngredient: null };
}


// --- VIEW MANAGEMENT ---

function handleSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchTerm = searchInput.value.toLowerCase();

    const filteredProducts = allProducts.filter(p => p.name.toLowerCase().includes(searchTerm));
    renderProducts(filteredProducts);
}

window.showProductView = (category) => {
    // Filter products by category (case-insensitive match)
    let products;

    if (category === 'all') {
        products = allProducts;
    } else {
        products = allProducts.filter(p =>
            p.category && p.category.toLowerCase() === category.toLowerCase()
        );
    }

    renderProducts(products);
    const grid = document.getElementById('productsGrid');
    if(grid) grid.dataset.currentCategory = category;
};

function showCategoryView() {
    renderProducts(productsByCategory['all'] || []);
}


// --- CART MANAGEMENT ---

window.addToCart = function(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return showNotification('Product not found', 'error');

    const existingItem = cart.find(item => item.id === productId);
    const quantityInCart = existingItem ? existingItem.quantity : 0;
    const newQuantity = quantityInCart + 1;

    const hasStock = (product.stock || 0) > 0;
    const hasRecipe = product.recipe && product.recipe.length > 0;

    if (hasStock) {
        if (newQuantity > product.stock) {
            return showNotification('Cannot add more than available stock', 'error');
        }
    } else if (hasRecipe) {
        const canMakeResult = checkIfCanMakeProduct(product, newQuantity);
        if (!canMakeResult.canMake) {
            return showNotification(`Not enough main stock of ${canMakeResult.missingIngredient} to add another ${product.name}.`, 'error');
        }
    } else {
        return showNotification('Product is out of stock', 'error');
    }
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            id: product.id, 
            name: product.name, 
            price: parseFloat(product.price),
            quantity: 1, 
            stock: product.stock, 
            recipe: product.recipe || [],
            addOns: []
        });
    }
    updateCartDisplay();
    showNotification(`${product.name} added to cart`, 'success');
}

window.updateQuantity = async function(productId, change) {
    const item = cart.find(i => i.id === productId);
    if (!item) return;

    // Require admin authentication for quantity decrease
    if (change < 0) {
        const authResult = await showAdminPasswordModal();
        if (!authResult || !authResult.success) {
            showNotification('Admin authentication required to decrease quantity', 'error');
            return;
        }
    }

    const newQuantity = item.quantity + change;

    if (newQuantity <= 0) {
        // Don't call voidItem again - just remove from cart directly
        // since we already authenticated above
        const index = cart.findIndex(i => i.id === productId);
        if (index > -1) {
            const itemName = cart[index].name;
            cart.splice(index, 1);
            updateCartDisplay();
            showNotification(`${itemName} removed from cart`, 'success');
        }
        return;
    }

    const hasStock = (item.stock || 0) > 0;
    const hasRecipe = item.recipe && item.recipe.length > 0;

    if (hasStock) {
        if (newQuantity > item.stock) {
            showNotification('Cannot exceed available stock', 'error');
            return;
        }
    } else if (hasRecipe) {
        const product = allProducts.find(p => p.id === productId);
        const canMakeResult = checkIfCanMakeProduct(product, newQuantity);
        if (!canMakeResult.canMake) {
            showNotification(`Not enough main stock of ${canMakeResult.missingIngredient} for this quantity.`, 'error');
            return;
        }
    } else {
        showNotification('Cannot exceed available stock', 'error');
        return;
    }

    item.quantity = newQuantity;
    updateCartDisplay();
}

window.setQuantity = async function(productId, value) {
    const item = cart.find(i => i.id === productId);
    if (!item) return;

    let newQuantity = parseInt(value);

    // Validate input
    if (isNaN(newQuantity) || newQuantity < 1) {
        newQuantity = 1;
    } else if (newQuantity > 999) {
        newQuantity = 999;
    }

    // Require admin authentication for quantity decrease
    if (newQuantity < item.quantity) {
        const authResult = await showAdminPasswordModal();
        if (!authResult || !authResult.success) {
            showNotification('Admin authentication required to decrease quantity', 'error');
            updateCartDisplay(); // Reset to original value
            return;
        }
    }

    const hasStock = (item.stock || 0) > 0;
    const hasRecipe = item.recipe && item.recipe.length > 0;

    if (hasStock) {
        if (newQuantity > item.stock) {
            showNotification(`Only ${item.stock} in stock available`, 'error');
            newQuantity = item.stock;
        }
    } else if (hasRecipe) {
        const product = allProducts.find(p => p.id === productId);
        const canMakeResult = checkIfCanMakeProduct(product, newQuantity);
        if (!canMakeResult.canMake) {
            showNotification(`Not enough main stock of ${canMakeResult.missingIngredient} for this quantity.`, 'error');
            // Keep current quantity
            updateCartDisplay();
            return;
        }
    } else {
        showNotification('Cannot exceed available stock', 'error');
        updateCartDisplay();
        return;
    }

    item.quantity = newQuantity;
    updateCartDisplay();
}

window.removeFromCart = function(productId) {
    const index = cart.findIndex(i => i.id === productId);
    if (index > -1) {
        const itemName = cart[index].name;
        cart.splice(index, 1);
        updateCartDisplay();
        showNotification(`${itemName} removed from cart`, 'info');
    }
}

function updateCartDisplay() {
    const cartItemsContainer = document.getElementById('cartItems');
    const cartCount = document.getElementById('cartCount');
    const cartEmptyMsg = document.getElementById('cartEmptyMsg');
    const mobileCartCount = document.getElementById('mobileCartCount');

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '';
        cartEmptyMsg.style.display = 'block';
    } else {
        cartEmptyMsg.style.display = 'none';
        cartItemsContainer.innerHTML = cart.map(item => {
            const addOnsText = item.addOns && item.addOns.length > 0
                ? `<br><small style="color: #666;">+ ${item.addOns.map(a => a.name).join(', ')}</small>`
                : '';

            return `
            <div class="cart-item">
                <div class="item-info">
                    <p class="item-name">${escapeHtml(item.name)}${addOnsText}</p>
                    <p class="item-price">₱${item.price.toFixed(2)}</p>
                    <button class="modify-btn" onclick="modifyProduct(${item.id})" style="margin-top: 5px; padding: 4px 12px; background: #ff9800; color: white; border: none; border-radius: 4px; font-size: 11px; cursor: pointer; font-weight: 600;">
                        <i class="fa-solid fa-pen-to-square"></i> Modify
                    </button>
                </div>
                <div class="item-controls">
                    <button class="qty-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                    <input type="number" class="qty-input" value="${item.quantity}" min="1" max="999"
                           onchange="setQuantity(${item.id}, this.value)"
                           onkeypress="if(event.key==='Enter') this.blur()">
                    <button class="qty-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                </div>
                <div class="item-total">₱${(item.price * item.quantity).toFixed(2)}</div>
                <button class="remove-btn" onclick="voidItem(${item.id})" title="Void Item (Requires Admin)">&times;</button>
            </div>
        `;
        }).join('');
    }

    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    if(mobileCartCount) {
        mobileCartCount.textContent = totalItems;
    }

    updateCartTotals();
}

function updateCartTotals() {
    let subtotal = 0;
    
    cart.forEach(item => {
        const itemPrice = (item.price || 0) * item.quantity;
        const addOnsPrice = (item.addOns || []).reduce((sum, addOn) => sum + addOn.price, 0) * item.quantity;
        subtotal += itemPrice + addOnsPrice;
    });
    
    const discountPercent = parseFloat(document.getElementById('discountInput').value) || 0;
    const discountType = window.currentDiscount?.type || 'regular';
    
    let total = subtotal;
    let vatAmount = 0;
    let discountAmount = 0;
    
    if (discountType === 'senior' || discountType === 'pwd') {
        // VAT-inclusive calculation
        const vatRate = 0.12;
        const vatableAmount = subtotal / (1 + vatRate);
        vatAmount = subtotal - vatableAmount;
        
        // 20% discount on vatable amount
        discountAmount = vatableAmount * 0.20;
        
        // Total = Subtotal - Discount - VAT
        total = subtotal - discountAmount - vatAmount;
    } else {
        // Regular discount
        discountAmount = subtotal * (discountPercent / 100);
        total = subtotal - discountAmount;
    }

    document.getElementById('subtotalDisplay').textContent = `₱${subtotal.toFixed(2)}`;
    document.getElementById('totalDisplay').textContent = `₱${total.toFixed(2)}`;
}

function clearCart() {
    cart = [];
    document.getElementById('discountInput').value = 0;
    document.getElementById('discountInput').disabled = false;
    window.currentDiscount = null;
    updateCartDisplay();
}

// --- ADD-ONS MODAL FUNCTIONS ---

function createAddOnsModal() {
    const modalHTML = `
        <div id="addOnsModal" class="payment-modal">
            <div class="payment-modal-card" style="max-width: 700px; max-height: 80vh; overflow-y: auto;">
                <h3>Add-ons for <span id="addOnsProductName"></span></h3>
                <p style="color: #666; margin-bottom: 20px;">Select any add-ons you'd like (optional)</p>
                
                <div id="addOnsGrid" class="add-ons-grid"></div>
                
                <div class="payment-modal-actions">
                    <button id="addOnsSkipBtn" class="btn secondary">No Add-ons</button>
                    <button id="addOnsContinueBtn" class="btn primary">Continue</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const style = document.createElement('style');
    style.textContent = `
        .add-ons-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .addon-card {
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .addon-card:hover {
            border-color: #ff9800;
            transform: translateY(-2px);
        }
        .addon-card.selected {
            border-color: #ff9800;
            background-color: #fff3e0;
        }
        .addon-card img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 6px;
            margin-bottom: 8px;
        }
        .addon-card .name {
            font-weight: 600;
            font-size: 13px;
            margin-bottom: 4px;
        }
        .addon-card .price {
            color: #ff9800;
            font-weight: 600;
        }
    `;
    document.head.appendChild(style);
    
    addOnsModal = document.getElementById('addOnsModal');
    addOnsProductName = document.getElementById('addOnsProductName');
    addOnsGrid = document.getElementById('addOnsGrid');
    addOnsSkipBtn = document.getElementById('addOnsSkipBtn');
    addOnsContinueBtn = document.getElementById('addOnsContinueBtn');
    
    addOnsSkipBtn.addEventListener('click', () => closeAddOnsModal([]));
    addOnsContinueBtn.addEventListener('click', () => closeAddOnsModal(selectedAddOns));
    addOnsModal.addEventListener('click', (e) => {
        if (e.target === addOnsModal) closeAddOnsModal([]);
    });
}

function showAddOnsModal(productName) {
    return new Promise((resolve) => {
        selectedAddOns = [];
        addOnsProductName.textContent = productName;
        
        const addOnsProducts = allProducts.filter(p => 
            p.category === 'Add Ons' && 
            (p.stock > 0 || (p.recipe && p.recipe.length > 0))
        );
        
        if (addOnsProducts.length === 0) {
            resolve([]);
            return;
        }
        
        addOnsGrid.innerHTML = addOnsProducts.map(product => `
            <div class="addon-card" data-id="${product.id}" onclick="toggleAddOn(${product.id}, '${escapeJs(product.name)}', ${product.price})">
                <img src="${product.image_url || PLACEHOLDER_IMAGE}" alt="${escapeHtml(product.name)}">
                <div class="name">${escapeHtml(product.name)}</div>
                <div class="price">₱${parseFloat(product.price).toFixed(2)}</div>
            </div>
        `).join('');
        
        addOnsModal.classList.add('is-visible');
        addOnsModalResolve = resolve;
    });
}

function closeAddOnsModal(addOns) {
    addOnsModal.classList.remove('is-visible');
    if (addOnsModalResolve) {
        addOnsModalResolve(addOns);
        addOnsModalResolve = null;
    }
}

window.toggleAddOn = function(productId, productName, productPrice) {
    const card = document.querySelector(`.addon-card[data-id="${productId}"]`);
    const index = selectedAddOns.findIndex(a => a.id === productId);
    
    if (index > -1) {
        selectedAddOns.splice(index, 1);
        card.classList.remove('selected');
    } else {
        selectedAddOns.push({
            id: productId,
            name: productName,
            price: parseFloat(productPrice)
        });
        card.classList.add('selected');
    }
}

// --- DISCOUNT MODAL FUNCTIONS ---

function setupDiscountModal() {
    const modalHTML = `
        <div id="discountModal" class="payment-modal">
            <div class="payment-modal-card" style="max-width: 450px;">
                <h3>Apply Discount</h3>
                <p style="color: #666; margin-bottom: 20px;">Select discount type</p>
                
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Discount Type:</label>
                    <select id="discountTypeSelect" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px;">
                        <option value="regular">Regular Discount</option>
                        <option value="senior">Senior Citizen (20% + VAT Exempt)</option>
                        <option value="pwd">PWD (20% + VAT Exempt)</option>
                    </select>
                </div>
                
                <div id="discountIdGroup" style="margin-bottom: 20px; display: none;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">ID Number:</label>
                    <input type="text" id="discountIdInput" placeholder="Enter ID/OSCA Number" 
                           style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px;">
                    <small style="color: #666; display: block; margin-top: 5px;">Required for Senior Citizen and PWD discounts</small>
                </div>
                
                <div class="payment-modal-actions">
                    <button id="discountModalCancel" class="btn secondary">Cancel</button>
                    <button id="discountModalApply" class="btn primary">Apply Discount</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    discountModal = document.getElementById('discountModal');
    discountTypeSelect = document.getElementById('discountTypeSelect');
    discountIdInput = document.getElementById('discountIdInput');
    discountIdGroup = document.getElementById('discountIdGroup');
    discountModalCancel = document.getElementById('discountModalCancel');
    discountModalApply = document.getElementById('discountModalApply');
    
    discountTypeSelect.addEventListener('change', () => {
        const type = discountTypeSelect.value;
        if (type === 'senior' || type === 'pwd') {
            discountIdGroup.style.display = 'block';
            discountIdInput.required = true;
        } else {
            discountIdGroup.style.display = 'none';
            discountIdInput.required = false;
            discountIdInput.value = '';
        }
    });
    
    discountModalCancel.addEventListener('click', closeDiscountModal);
    discountModalApply.addEventListener('click', applyDiscount);
    discountModal.addEventListener('click', (e) => {
        if (e.target === discountModal) closeDiscountModal();
    });
}

function showDiscountModal() {
    if (cart.length === 0) {
        showNotification('Please add items to cart first', 'error');
        return;
    }
    
    discountTypeSelect.value = 'regular';
    discountIdInput.value = '';
    discountIdGroup.style.display = 'none';
    discountModal.classList.add('is-visible');
}

function closeDiscountModal() {
    discountModal.classList.remove('is-visible');
}

async function applyDiscount() {
    const discountType = discountTypeSelect.value;
    const discountId = discountIdInput.value.trim();

    if ((discountType === 'senior' || discountType === 'pwd') && !discountId) {
        showNotification('Please enter ID number for senior/PWD discount', 'error');
        return;
    }

    // Close discount modal first BEFORE authentication
    closeDiscountModal();

    // Small delay to ensure discount modal is fully closed before showing admin modal
    await new Promise(resolve => setTimeout(resolve, 100));

    // Require admin authentication BEFORE applying discount
    const authResult = await showAdminPasswordModal();

    if (!authResult || !authResult.success) {
        showNotification('Admin authentication required to apply discounts', 'error');
        return;
    }

    // Admin authenticated - now apply the discount IMMEDIATELY
    window.currentDiscount = {
        type: discountType,
        id: discountId
    };

    const discountInput = document.getElementById('discountInput');
    if (discountType === 'senior' || discountType === 'pwd') {
        discountInput.value = '20';
        discountInput.disabled = true;
    } else {
        discountInput.disabled = false;
    }

    updateCartTotals();

    let message = 'Regular discount applied';
    if (discountType === 'senior') message = 'Senior Citizen discount applied (20% + VAT Exempt)';
    if (discountType === 'pwd') message = 'PWD discount applied (20% + VAT Exempt)';

    showNotification(message, 'success');
}

// --- PAYMENT MODAL FUNCTIONS ---

function showPaymentModal(paymentMethod) {
    return new Promise((resolve) => {
        paymentModalTitle.textContent = `${paymentMethod} Payment Details`;
        paymentCustomerName.value = '';
        paymentRefNum.value = '';
        paymentModal.classList.add('is-visible');
        paymentCustomerName.focus();
        
        paymentModalResolve = resolve;
    });
}

function closePaymentModal() {
    paymentModal.classList.remove('is-visible');
    if (paymentModalResolve) {
        paymentModalResolve(null);
        paymentModalResolve = null;
    }
}

function confirmPaymentDetails() {
    const details = {
        cust_name: paymentCustomerName.value.trim(),
        ref_num: paymentRefNum.value.trim()
    };

    if (!details.ref_num) {
        showNotification('Please enter a reference number.', 'error');
        return;
    }

    // Validate reference number: must be exactly 13 digits
    const refNumPattern = /^\d{13}$/;
    if (!refNumPattern.test(details.ref_num)) {
        showNotification('Reference number must be exactly 13 digits only (no letters or special characters).', 'error');
        return;
    }

    paymentModal.classList.remove('is-visible');
    if (paymentModalResolve) {
        paymentModalResolve(details);
        paymentModalResolve = null;
    }
}

// --- RECEIPT PREVIEW MODAL FUNCTIONS (Updated to fix styles & size) ---

function setupReceiptPreviewModal() {
    // Make modal exactly 300px + padding to simulate receipt width
    const modalHTML = `
        <div id="receiptPreviewModal" class="payment-modal" style="z-index: 10001;">
            <div class="payment-modal-card" style="width: 340px; padding: 0; border-radius: 8px; overflow: hidden;">
                <button class="receipt-modal-close" id="receiptPreviewClose" style="position: absolute; top: 10px; right: 10px; background: #eee; border: none; width: 30px; height: 30px; border-radius: 50%; cursor: pointer; font-size: 20px;">&times;</button>
                
                <div id="receiptPreviewContent" style="padding: 0; background: white; overflow-y: auto; max-height: 80vh;">
                    <!-- Receipt content will be inserted here -->
                </div>
                
                <div style="padding: 15px; background: #f9f9f9; border-top: 1px solid #eee; text-align: center;">
                    <button id="receiptPreviewPrint" class="btn primary" style="width: 100%; padding: 10px;">
                        <i class="fa-solid fa-print"></i> Print Receipt
                    </button>
                </div>
            </div>
        </div>
    `;
    
    if (!document.getElementById('receiptPreviewModal')) {
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }
    
    receiptPreviewModal = document.getElementById('receiptPreviewModal');
    receiptPreviewClose = document.getElementById('receiptPreviewClose');
    receiptPreviewPrint = document.getElementById('receiptPreviewPrint');
    receiptPreviewContent = document.getElementById('receiptPreviewContent');
    
    receiptPreviewClose.addEventListener('click', closeReceiptPreview);
    receiptPreviewPrint.addEventListener('click', printReceipt);
    receiptPreviewModal.addEventListener('click', (e) => {
        if (e.target === receiptPreviewModal) closeReceiptPreview();
    });
}

// ============================================
// ORDER COMPLETE MODAL
// ============================================

let storedReceiptHTML = null;

function showOrderCompleteModal(orderId, total, paymentMethod, receiptHTML) {
    storedReceiptHTML = receiptHTML;

    const modal = document.getElementById('orderCompleteModal');
    const orderNumber = document.getElementById('orderCompleteNumber');
    const orderTotal = document.getElementById('orderCompleteTotal');
    const orderPayment = document.getElementById('orderCompletePayment');

    if (modal && orderNumber && orderTotal && orderPayment) {
        orderNumber.textContent = `#${orderId}`;
        orderTotal.textContent = `₱${parseFloat(total).toFixed(2)}`;
        orderPayment.textContent = paymentMethod;

        modal.classList.add('is-visible');
        showNotification('Order processed successfully!', 'success');
    }
}

function closeOrderCompleteModal() {
    const modal = document.getElementById('orderCompleteModal');
    if (modal) {
        modal.classList.remove('is-visible');

        // Clear cart and reload
        clearCart();
        window.currentDiscount = null;
        document.getElementById('discountInput').disabled = false;
        loadProducts();

        const currentCategory = document.getElementById('productsGrid')?.dataset.currentCategory || 'all';
        showProductView(currentCategory);

        storedReceiptHTML = null;
    }
}

function setupOrderCompleteModal() {
    const viewReceiptBtn = document.getElementById('orderCompleteViewReceipt');
    const closeBtn = document.getElementById('orderCompleteClose');
    const modal = document.getElementById('orderCompleteModal');

    if (viewReceiptBtn) {
        viewReceiptBtn.addEventListener('click', () => {
            // Close the order complete modal
            modal.classList.remove('is-visible');

            // Show the receipt preview if available
            if (storedReceiptHTML) {
                showReceiptPreview(storedReceiptHTML);
            }
            storedReceiptHTML = null;
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            closeOrderCompleteModal();
        });
    }

    // Close on clicking outside the modal card
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeOrderCompleteModal();
            }
        });
    }
}

function showReceiptPreview(receiptHTML) {
    if (receiptPreviewContent && receiptHTML) {
        // Save for printing later
        currentReceiptHTML = receiptHTML;

        // Inject HTML - wrap in a div to ensure centering/sizing
        receiptPreviewContent.innerHTML = `
            <div style="width: 300px; margin: 0 auto; padding: 10px; font-family: 'Courier New', monospace; font-size: 12px; color: #000; text-align: left;">
                ${receiptHTML}
            </div>
        `;

        // Strip out any <style> tags that affect 'body' to prevent preview from breaking page
        const styles = receiptPreviewContent.getElementsByTagName('style');
        for (let i = styles.length - 1; i >= 0; i--) {
            if (styles[i].innerHTML.includes('body {')) {
                styles[i].parentNode.removeChild(styles[i]);
            }
        }

        receiptPreviewModal.classList.add('is-visible');
    }
}

function closeReceiptPreview() {
    receiptPreviewModal.classList.remove('is-visible');
    // Clean up
    currentReceiptHTML = "";
    // Clear cart after closing
    clearCart();
    window.currentDiscount = null;
    document.getElementById('discountInput').disabled = false;

    // Only reload products - ingredients will be updated via storage event from server
    loadProducts();

    // Refresh the current product view to show updated stock
    const currentCategory = document.getElementById('productsGrid')?.dataset.currentCategory || 'all';
    showProductView(currentCategory);

    // loadRecentOrders(); // REMOVED: Recent Orders panel no longer needed
    if (cartCol && cartCol.classList.contains('is-mobile-open')) {
        toggleMobileCart();
    }
}

function printReceipt() {
    if (!currentReceiptHTML) return;

    // Create an invisible iframe to print without affecting main page styles
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    
    document.body.appendChild(iframe);
    
    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
        <html>
        <head>
            <title>Print Receipt</title>
            <style>
                @page { size: 80mm auto; margin: 0; }
                body { margin: 0; padding: 10px; font-family: 'Courier New', monospace; font-size: 12px; width: 80mm; color: #000; }
                .receipt-container { width: 100%; max-width: 80mm; }
                /* Re-add essential styles here if they were stripped or use inline styles from template */
            </style>
        </head>
        <body>
            ${currentReceiptHTML}
        </body>
        </html>
    `);
    doc.close();
    
    iframe.contentWindow.focus();
    setTimeout(() => {
        iframe.contentWindow.print();
        // Remove iframe after printing to clean up
        setTimeout(() => {
            document.body.removeChild(iframe);
            closeReceiptPreview();
        }, 1000);
    }, 500);
}


// --- ORDER PROCESSING ---

async function processOrder() {
    if (cart.length === 0) {
        return showNotification('Cart is empty', 'error');
    }

    // NOTE: Automatic add-ons prompt removed - users now use the "Modify" button on cart items
    // to add or change add-ons at any time before processing the order

    const paymentMethod = getSelectedPaymentMethod(); // Use button-based selection
    let paymentDetails = {};

    if (paymentMethod === 'Gcash' || paymentMethod === 'Card') {
        paymentDetails = await showPaymentModal(paymentMethod);
        
        if (paymentDetails === null) {
            showNotification('Payment cancelled.', 'info');
            return; 
        }
    }

    const orderItems = [];
    cart.forEach(item => {
        orderItems.push({ 
            id: item.id, 
            quantity: item.quantity, 
            price: item.price 
        });
        
        if (item.addOns && item.addOns.length > 0) {
            item.addOns.forEach(addOn => {
                orderItems.push({
                    id: addOn.id,
                    quantity: item.quantity,
                    price: addOn.price
                });
            });
        }
    });

    const discountInfo = window.currentDiscount || { type: 'regular', id: '' };
    const diningOption = getSelectedDiningOption(); // Use button-based selection

    const orderData = {
        items: orderItems,
        total: parseFloat(document.getElementById('totalDisplay').textContent.replace('₱', '')),
        discount: parseFloat(document.getElementById('discountInput').value || 0),
        discount_type: discountInfo.type,
        discount_id: discountInfo.id,
        payment_method: paymentMethod,
        dining_option: diningOption,
        customer_name: "Walk-in",
        payment_details: paymentDetails
    };
    
    const processOrderBtn = document.getElementById('processOrderBtn');
    processOrderBtn.disabled = true;
    processOrderBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';

    try {
        const response = await fetch('/api/process-order/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
            body: JSON.stringify(orderData)
        });
        const data = await response.json();

        if (response.ok && data.success) {
            // Show Order Complete Modal instead of just notification
            showOrderCompleteModal(data.order_id, orderData.total, paymentMethod, data.receipt_html);

        } else {
            showNotification(data.error || 'Failed to process order. Please try again.', 'error');
            const currentCategory = document.getElementById('productsGrid').dataset.currentCategory || 'all';
            showProductView(currentCategory);
        }
    } catch (error) {
        console.error('Error processing order:', error);
        showNotification('Network error. Could not process order.', 'error');
        const currentCategory = document.getElementById('productsGrid').dataset.currentCategory || 'all';
        showProductView(currentCategory);
    } finally {
        processOrderBtn.disabled = false;
        processOrderBtn.innerHTML = '<i class="fa-solid fa-check"></i> Process Order';
    }
}

function toggleMobileCart() {
    if (cartCol) {
        cartCol.classList.toggle('is-mobile-open');
        document.body.classList.toggle('cart-overlay-open');
    }
}


// ============================================
// NEW: BUTTON-BASED CONTROLS (CATEGORY, PAYMENT, DINING)
// ============================================

function setupButtonControls() {
    // Category Buttons
    const categoryBtns = document.querySelectorAll('.category-btn');
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active from all
            categoryBtns.forEach(b => {
                b.classList.remove('active');
                b.style.background = 'white';
                b.style.color = '#333';
                b.style.borderColor = '#ddd';
            });
            // Add active to clicked
            this.classList.add('active');
            const category = this.dataset.category;

            // Special styling for bestselling
            if (category === 'bestselling') {
                this.style.background = '#ffc107';
                this.style.color = '#333';
                this.style.borderColor = '#ffc107';
            } else {
                this.style.background = '#8B4513';
                this.style.color = 'white';
                this.style.borderColor = '#8B4513';
            }

            // Show products for category
            if (category === 'bestselling') {
                showBestSellingProducts();
            } else {
                showProductView(category);
            }
        });
    });

    // Dining Option Buttons
    const diningBtns = document.querySelectorAll('.dining-btn');
    diningBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active from all
            diningBtns.forEach(b => {
                b.classList.remove('active');
                b.style.background = 'white';
                b.style.color = '#333';
                b.style.borderColor = '#ddd';
                b.style.boxShadow = 'none';
            });
            // Add active to clicked with glow effect
            this.classList.add('active');
            this.style.background = '#28a745';
            this.style.color = 'white';
            this.style.borderColor = '#28a745';
            this.style.boxShadow = '0 0 15px rgba(40, 167, 69, 0.5)';
        });
    });

    // Payment Method Buttons
    const paymentBtns = document.querySelectorAll('.payment-btn');
    paymentBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active from all
            paymentBtns.forEach(b => {
                b.classList.remove('active');
                b.style.background = 'white';
                b.style.color = '#333';
                b.style.borderColor = '#ddd';
                b.style.boxShadow = 'none';
            });
            // Add active to clicked with glow effect
            this.classList.add('active');
            this.style.background = '#28a745';
            this.style.color = 'white';
            this.style.borderColor = '#28a745';
            this.style.boxShadow = '0 0 15px rgba(40, 167, 69, 0.5)';
        });
    });
}

// Get selected dining option from buttons
function getSelectedDiningOption() {
    const activeDiningBtn = document.querySelector('.dining-btn.active');
    return activeDiningBtn ? activeDiningBtn.dataset.option : 'dine-in';
}

// Get selected payment method from buttons
function getSelectedPaymentMethod() {
    const activePaymentBtn = document.querySelector('.payment-btn.active');
    return activePaymentBtn ? activePaymentBtn.dataset.method : 'Cash';
}

// Show Best Selling Products (sorted by sales count from OrderItems)
async function showBestSellingProducts() {
    try {
        const response = await fetch('/api/best-selling-products/');
        const data = await response.json();

        if (data.success && data.products) {
            renderProducts(data.products);
            const grid = document.getElementById('productsGrid');
            if(grid) grid.dataset.currentCategory = 'bestselling';
        } else {
            showNotification('Failed to load best-selling products', 'error');
            // Fallback to all products
            renderProducts(allProducts);
        }
    } catch (error) {
        console.error('Error loading best-selling products:', error);
        showNotification('Failed to load best-selling products', 'error');
        // Fallback to all products
        renderProducts(allProducts);
    }
}


// ============================================
// NEW: ADMIN AUTHENTICATION FOR DISCOUNT/VOID
// ============================================

let adminPasswordModal;
let adminPasswordResolve = null;
let adminPasswordModalInitialized = false;
let isAuthenticating = false; // Prevent double-submission

function setupAdminPasswordModal() {
    // Prevent duplicate initialization
    if (adminPasswordModalInitialized) {
        console.log('Admin password modal already initialized');
        return;
    }

    adminPasswordModal = document.getElementById('adminPasswordModal');
    const adminPasswordCancel = document.getElementById('adminPasswordCancel');
    const adminPasswordConfirm = document.getElementById('adminPasswordConfirm');
    const adminUsername = document.getElementById('adminUsername');
    const adminPassword = document.getElementById('adminPassword');

    if (!adminPasswordModal || !adminPasswordCancel || !adminPasswordConfirm || !adminUsername || !adminPassword) {
        console.error('Admin password modal elements not found');
        return;
    }

    // Handler function for authentication
    const handleAuthentication = async () => {
        // Prevent double submission
        if (isAuthenticating) {
            console.log('Authentication already in progress, ignoring duplicate request');
            return;
        }

        const username = adminUsername.value.trim();
        const password = adminPassword.value.trim();

        if (!username || !password) {
            showNotification('Please enter both username and password', 'error');
            return;
        }

        isAuthenticating = true;
        console.log('Starting authentication process...');

        try {
            // Verify admin credentials via API
            const isValid = await verifyAdminCredentials(username, password);

            if (isValid) {
                showNotification('Admin authenticated successfully', 'success');
                // CRITICAL: Call resolve BEFORE closing modal (which nulls the resolve function)
                const resolveFunc = adminPasswordResolve;
                closeAdminPasswordModal();
                if (resolveFunc) {
                    console.log('Resolving authentication promise with success');
                    // Return credentials along with success status
                    resolveFunc({ success: true, username: username, password: password });
                }
            } else {
                // Error message is already shown in verifyAdminCredentials
                adminPassword.value = '';
                adminUsername.focus();
            }
        } catch (error) {
            console.error('Authentication handler error:', error);
            showNotification('Authentication error occurred', 'error');
        } finally {
            isAuthenticating = false;
        }
    };

    // Cancel button handler
    adminPasswordCancel.addEventListener('click', () => {
        console.log('Authentication cancelled by user');
        closeAdminPasswordModal();
        if (adminPasswordResolve) adminPasswordResolve({ success: false });
    });

    // Authenticate button handler
    adminPasswordConfirm.addEventListener('click', handleAuthentication);

    // Add Enter key support on password field
    adminPassword.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleAuthentication();
        }
    });

    // Add Enter key support on username field
    adminUsername.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            // Move focus to password field if username is filled
            if (adminUsername.value.trim()) {
                adminPassword.focus();
            }
        }
    });

    // Backdrop click handler
    adminPasswordModal.addEventListener('click', (e) => {
        if (e.target === adminPasswordModal) {
            console.log('Modal closed by backdrop click');
            closeAdminPasswordModal();
            if (adminPasswordResolve) adminPasswordResolve({ success: false });
        }
    });

    adminPasswordModalInitialized = true;
    console.log('Admin password modal initialized successfully');
}

function showAdminPasswordModal() {
    console.log('showAdminPasswordModal called');

    // **CRITICAL FIX**: If modal is already visible, don't create a new promise
    // This prevents double authentication scenarios
    if (adminPasswordModal && adminPasswordModal.classList.contains('is-visible')) {
        console.warn('⚠️ Modal already visible! Returning existing promise to prevent duplicate auth.');
        // Return a promise that will be resolved by the existing modal flow
        return new Promise((resolve) => {
            // Store this resolve function so when the modal completes, both promises resolve
            const originalResolve = adminPasswordResolve;
            adminPasswordResolve = (result) => {
                if (originalResolve) originalResolve(result);
                resolve(result);
            };
        });
    }

    return new Promise((resolve) => {
        adminPasswordResolve = resolve;
        isAuthenticating = false; // Reset authentication flag

        const usernameField = document.getElementById('adminUsername');
        const passwordField = document.getElementById('adminPassword');

        if (usernameField) usernameField.value = '';
        if (passwordField) passwordField.value = '';

        if (adminPasswordModal) {
            console.log('✅ Showing admin modal');
            adminPasswordModal.classList.add('is-visible');
            document.body.classList.add('modal-open');  // Lock body scroll
            // Focus on username field for better UX
            setTimeout(() => {
                if (usernameField) {
                    usernameField.focus();
                    console.log('✅ Username field focused');
                }
            }, 150);
        } else {
            console.error('❌ adminPasswordModal is null!');
        }
    });
}

function closeAdminPasswordModal() {
    console.log('closeAdminPasswordModal called');
    if (adminPasswordModal) {
        adminPasswordModal.classList.remove('is-visible');
        document.body.classList.remove('modal-open');  // Unlock body scroll
        console.log('✅ Modal closed and body unlocked');
    }
    adminPasswordResolve = null;
    isAuthenticating = false; // Reset authentication flag
}

async function verifyAdminCredentials(username, password) {
    try {
        console.log('Verifying admin credentials...');
        console.log('Username:', username);
        console.log('Password length:', password ? password.length : 0);

        const response = await fetch('/api/verify-admin/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken()
            },
            body: JSON.stringify({ username, password })
        });

        console.log('Response status:', response.status);
        const data = await response.json();
        console.log('Response data:', data);

        if (!data.success) {
            console.error('Authentication failed:', data.error);
            showNotification(data.error || 'Authentication failed', 'error');
        }

        return data.success === true && data.is_admin === true;
    } catch (error) {
        console.error('Error verifying admin:', error);
        showNotification('Network error during authentication', 'error');
        return false;
    }
}

async function requireAdminForDiscount() {
    // First, show the discount modal to let user select discount type
    // This will be handled by the applyDiscount function which now requires auth
    showDiscountModal();
}

// Void function with admin authentication and comprehensive error handling
window.voidItem = async function(productId) {
    // Validate input parameters
    if (productId === null || productId === undefined) {
        showNotification('Invalid item ID', 'error');
        return;
    }

    // Validate cart exists and is an array
    if (!Array.isArray(cart)) {
        showNotification('Cart is not properly initialized', 'error');
        return;
    }

    try {
        // Authenticate admin
        console.log('Requesting admin authentication for void action...');
        const authResult = await showAdminPasswordModal();

        if (!authResult || !authResult.success) {
            showNotification('Admin authentication required to void items', 'error');
            return;
        }

        // Find the item in cart
        const index = cart.findIndex(i => i.id === productId);

        if (index === -1) {
            showNotification('Item not found in cart', 'error');
            return;
        }

        // Get item details before removing
        const voidedItem = cart[index];
        const itemName = voidedItem.name;
        const itemPrice = voidedItem.price;
        const itemQuantity = voidedItem.quantity || 1;

        // Log void action to audit trail (server-side) with admin credentials
        try {
            const auditResponse = await fetch('/api/log-void-action/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCSRFToken()
                },
                body: JSON.stringify({
                    item_id: productId,
                    item_name: itemName,
                    item_price: itemPrice,
                    quantity: itemQuantity,
                    terminal: 'Admin POS',
                    admin_username: authResult.username,
                    admin_password: authResult.password
                })
            });

            const auditData = await auditResponse.json();

            if (!auditData.success) {
                console.warn('Failed to log void action to audit trail:', auditData.error);
                // Continue with void even if audit logging fails
            } else {
                console.log('Void action logged to audit trail successfully');
            }
        } catch (auditError) {
            console.error('Error logging void action to audit trail:', auditError);
            // Continue with void even if audit logging fails
        }

        // Remove the item from cart
        cart.splice(index, 1);
        updateCartDisplay();
        showNotification(`${itemName} voided successfully`, 'success');

    } catch (error) {
        console.error('Error voiding item:', error);
        showNotification('Failed to void item. Please try again.', 'error');
    }
};


// ============================================
// NEW: MODIFY PRODUCT (ADD-ONS)
// ============================================

window.modifyProduct = async function(productId) {
    const item = cart.find(i => i.id === productId);
    if (!item) return;

    // Pre-select existing add-ons
    selectedAddOns = item.addOns ? [...item.addOns] : [];

    const addOns = await showAddOnsModalForModify(item.name, item.addOns || []);

    // Update the cart item with new add-ons
    item.addOns = addOns;
    updateCartDisplay();

    if (addOns.length > 0) {
        showNotification(`Add-ons updated for ${item.name}`, 'success');
    } else {
        showNotification(`Add-ons removed from ${item.name}`, 'info');
    }
}

function showAddOnsModalForModify(productName, existingAddOns = []) {
    return new Promise((resolve) => {
        selectedAddOns = [...existingAddOns];
        addOnsProductName.textContent = productName;

        const addOnsProducts = allProducts.filter(p =>
            p.category === 'Add Ons' &&
            (p.stock > 0 || (p.recipe && p.recipe.length > 0))
        );

        if (addOnsProducts.length === 0) {
            resolve([]);
            return;
        }

        addOnsGrid.innerHTML = addOnsProducts.map(product => {
            // Check if this add-on is already selected
            const isSelected = existingAddOns.some(a => a.id === product.id);
            return `
                <div class="addon-card ${isSelected ? 'selected' : ''}" data-id="${product.id}" onclick="toggleAddOn(${product.id}, '${escapeJs(product.name)}', ${product.price})">
                    <img src="${product.image_url || PLACEHOLDER_IMAGE}" alt="${escapeHtml(product.name)}">
                    <div class="name">${escapeHtml(product.name)}</div>
                    <div class="price">₱${parseFloat(product.price).toFixed(2)}</div>
                </div>
            `;
        }).join('');

        addOnsModal.classList.add('is-visible');
        addOnsModalResolve = resolve;
    });
}